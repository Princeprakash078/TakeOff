
from fastapi import FastAPI

app=FastAPI()
usage={"requests":0}

@app.post("/track")
def track():
    usage["requests"]+=1
    return usage

@app.get("/usage")
def usage_data():
    return usage

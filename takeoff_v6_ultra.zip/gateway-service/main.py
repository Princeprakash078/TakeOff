
from fastapi import FastAPI
from pydantic import BaseModel
import httpx

MODEL="http://model-service:8002"
PROVIDERS="http://providers:8005"

app=FastAPI()

class Prompt(BaseModel):
    prompt:str

@app.post("/run/model/{model}/{version}")
async def run_model(model:str,version:str,p:Prompt):
    async with httpx.AsyncClient() as c:
        r=await c.post(f"{MODEL}/predict/{model}/{version}",json={"prompt":p.prompt})
    return r.json()

@app.post("/run/provider/{name}")
async def run_provider(name:str,p:Prompt):
    async with httpx.AsyncClient() as c:
        r=await c.post(f"{PROVIDERS}/generate/{name}",json={"prompt":p.prompt})
    return r.json()

@app.get("/metrics")
def metrics():
    return {"status":"ok","service":"gateway"}

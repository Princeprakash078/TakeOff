
from fastapi import FastAPI
from pydantic import BaseModel

app=FastAPI()
users={}

class User(BaseModel):
    username:str
    password:str

@app.post("/signup")
def signup(u:User):
    users[u.username]=u.password
    return {"user":u.username}

@app.post("/login")
def login(u:User):
    if users.get(u.username)==u.password:
        return {"status":"ok"}
    return {"error":"invalid"}


from fastapi import FastAPI

app=FastAPI()
agents={}

@app.post("/publish")
def publish(name:str):
    agents[name]={"status":"ready"}
    return {"agent":name}

@app.post("/run/{name}")
def run(name:str,task:str):
    return {"result":f"{name} executed {task}"}


from fastapi import FastAPI,UploadFile
from pydantic import BaseModel
import importlib.util,os

app=FastAPI()
models={}

class Prompt(BaseModel):
    prompt:str

def load_model(path):
    spec=importlib.util.spec_from_file_location("model",path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

@app.post("/upload/{name}/{version}")
async def upload(name:str,version:str,file:UploadFile):
    os.makedirs("models",exist_ok=True)
    path=f"models/{name}_{version}.py"
    with open(path,"wb") as f:
        f.write(await file.read())
    models[f"{name}:{version}"]=load_model(path)
    return {"uploaded":name,"version":version}

@app.post("/predict/{name}/{version}")
def predict(name:str,version:str,p:Prompt):
    m=models.get(f"{name}:{version}")
    if not m:
        return {"error":"model not found"}
    return {"result":m.predict(p.prompt)}

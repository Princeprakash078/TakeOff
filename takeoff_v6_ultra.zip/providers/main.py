
from fastapi import FastAPI
from pydantic import BaseModel

app=FastAPI()

class Prompt(BaseModel):
    prompt:str

@app.post("/generate/openai")
def openai(p:Prompt):
    return {"response":"OpenAI response: "+p.prompt}

@app.post("/generate/gemini")
def gemini(p:Prompt):
    return {"response":"Gemini response: "+p.prompt}

@app.post("/generate/ollama")
def ollama(p:Prompt):
    return {"response":"Ollama response: "+p.prompt}

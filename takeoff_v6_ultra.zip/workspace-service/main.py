
from fastapi import FastAPI

app=FastAPI()
projects={}

@app.post("/create")
def create(user:str,name:str):
    projects.setdefault(user,[]).append(name)
    return {"project":name}
